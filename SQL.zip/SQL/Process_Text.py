import os
import json


os.chdir('./')
options = '-cn --format json'
fsrc = 'Source1.txt'
fout = 'Mystem.txt'

os.system(r"./mystem " + options + ' ' + fsrc + ' ' + fout)

id22 = 0
id1 = 0
ntoken = 0
f = open(fout, 'r', encoding='utf-8')
fsql = open('Text.sql', 'w')
leftmark = ' '
rightmark = ' '

for line in f:
    result = json.loads(line.replace('\n', ' '))
    try:
        lemma = result['analysis'][0]['lex']
        token = result['text']
        id22 += 10
        fsql.write('INSERT INTO table2 (id2, token, lemma) VALUES (' + str(id22) +', "' + token.lower() + '", "' + lemma +'");\n' )

    except:
        if token == ' ':
            continue
        id1 += 1
        ntoken += 1
        leftmark = rightmark
        rightmark = result['text'].replace('\n', '')
        fsql.write('INSERT INTO table1 (id1, token, leftmark, rightmark, ntoken, id22) \
        VALUES ('
                   + str(id1) + ', ' +
                   '"'+ token + '"' + ', ' +
                   '"'+ leftmark + '"'+ ', ' +
                   '"'+ rightmark + '"'+ ', ' +
                   str(ntoken) + ', ' +
                   str(id22) +
                   ');\n')
        token = ' '


fsql.close()
f.close()


