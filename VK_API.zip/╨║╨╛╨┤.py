import urllib.request, json
import matplotlib.pyplot as plt
from matplotlib import style

def process_comm(postid, countmin='100'):
    req = urllib.request.Request('https://api.vk.com/method/wall.getComments?owner_id=-59763525&post_id='+postid+'&count='+countmin)
    response = urllib.request.urlopen(req)
    result = response.read().decode('utf-8')
    data = json.loads(result)
    counter = 0
    length = 0
    for onecom in data['response']:
        counter += 1
        if counter < 2:
            continue
        print('Комментатор', onecom['from_id'])
        one_l = len(onecom['text'].split())
        length += one_l
    print('>>>>', len(onecom['text'].split()), onecom['text'])
    average_com = length/(counter-1)
    print('Средняя длина комментария', average_com)
    return average_com

def process_user(user):
    req = urllib.request.Request('https://api.vk.com/method/users.get?user_ids={}&fields=home_town,bdate'.format(str(user)))
    response = urllib.request.urlopen(req)
    result = response.read().decode('utf-8')
    data = json.loads(result)
    if not data['response']:
        return None, None
    if 'bdate' not in (data['response'][0]):
        return None, None
    if 'home_town' not in (data['response'][0]):
        return None, None
    return data['response'][0]['bdate'], data['response'][0]['home_town']



offsets = [0, 100, 200, 300, 400, 500, 600, 700]
all_posts = []

for offset in offsets:
    req = urllib.request.Request('https://api.vk.com/method/wall.get?domain=monki_russia&count=100&offset='+str(offset))
    response = urllib.request.urlopen(req)
    result = response.read().decode('utf-8')
    data = json.loads(result)

    first_skip = 0
    count = 0
    for item in data['response']:
        first_skip += 1
        if first_skip < 2:
            continue
        if count > 100:
            break
        postid = item['id']
        ncom = item['comments']['count']
        if ncom > 0:
            bdate, hometown = process_user(item['from_id'])
            if not hometown:
                continue
            if not bdate:
                continue
            elif bdate.count('.') == 1:
                continue
            count += 1
            print('Автор поста:', item['from_id'])
            print('Дата рождения:', bdate, 'Город:', hometown)
            print(item['text'])
            post_length = len(item['text'].split())
            print('Длина поста:', post_length)
            norm_com = process_comm(str(postid))
            print('Соотношение', post_length, '/', norm_com)
            all_posts.append((item['from_id'], bdate, hometown, post_length, norm_com))
all_posts.sort()
print(len(all_posts))

cities = {item[2]:(0, 0, 0) for item in all_posts}
for item in all_posts:
    tot_pos_l = cities[item[2]][0] + item[3]
    tot_com_l = cities[item[2]][1] + item[4]
    nposts = cities[item[2]][2] + 1
    cities[item[2]] = (tot_pos_l, tot_com_l, nposts)
for city in cities:
    tot_pos_l, tot_com_l, nposts = cities[city]
    cities[city] = (tot_pos_l/nposts, tot_com_l/nposts, nposts)
print(cities)

ages = {2017 - int(item[1].split('.')[-1]): (0, 0, 0) for item in all_posts}
for item in all_posts:
    age = 2017 - int(item[1].split('.')[-1])
    tot_pos_l = ages[age][0] + item[3]
    tot_com_l = ages[age][1] + item[4]
    nposts = ages[age][2] + 1
    ages[age] = (tot_pos_l, tot_com_l, nposts)
for age in ages:
    tot_pos_l, tot_com_l, nposts = ages[age]
    ages[age] = (tot_pos_l/nposts, tot_com_l/nposts, nposts)
print(ages)

posts = {item[0]:(0, 0, 0) for item in all_posts}
for item in all_posts:
    tot_pos_l = posts[item[0]][0] + item[3]
    tot_com_l = posts[item[0]][1] + item[4]
    nposts = posts[item[0]][2] + 1
    posts[item[0]] = (tot_pos_l, tot_com_l, nposts)
for post in posts:
    tot_pos_l, tot_com_l, nposts = posts[post]
    posts[post] = (tot_pos_l/nposts, tot_com_l/nposts, nposts)
print(posts)

style.use('ggplot')

#Города + комментария с постами
Xaxis = [cities[city][0] for city in cities]
Yaxis = [cities[city][1] for city in cities]
plt.bar(Xaxis, Yaxis)
plt.title('Соотношение длин постов и комментариев с родным городом пользователя')
plt.ylabel('Средняя длина комментария')
plt.xlabel('Средняя длина поста')
plt.show()
plt.savefig('home_towns.png')

#Возраст + комментария с постами
Xaxis = [ages[age][0] for age in ages]
Yaxis = [ages[age][1] for age in ages]
plt.bar(Xaxis, Yaxis)
plt.title('Соотношение длин постов и комментариев с возрастом пользователя')
plt.ylabel('Средняя длина комментария')
plt.xlabel('Средняя длина поста')
plt.show()
plt.savefig('ages.png')

#Посты и комментария
Xaxis = [posts[post][0] for post in posts]
Yaxis = [posts[post][1] for post in posts]
plt.bar(Xaxis, Yaxis)
plt.title('Соотношение длин комментариев с постами')
plt.ylabel('Средняя длина комментария')
plt.xlabel('Средняя длина поста')
plt.show()
plt.savefig('comments_and_posts.png')

