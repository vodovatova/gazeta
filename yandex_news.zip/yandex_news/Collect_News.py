'''
Обработка подборки новостей
Тема: СК проверяет данные о выгнавшем девочку на мороз контролере в Москве
https://news.yandex.ru/yandsearch?lr=213&cl4url=www.gazeta.ru%2Fsocial%2Fnews%2F2016%2F11%2F30%2Fn_9396383.shtml&content=alldocs&from=story
'''
import urllib.request
from bs4 import BeautifulSoup
import re

regSpace = re.compile('\s{2,}', flags=re.U | re.DOTALL)

# ТАСС
url = 'http://tass.ru/proisshestviya/3827375'
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('article1.txt', 'w', encoding='utf-8')

h1 = bsObj.h1
f.write(h1.get_text()+'\n')


article = bsObj.find("div", {"class":"b-material-text__l js-mediator-article"})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub("", t)
    f.write(clean_t+'\n')

f.close()



# Радио Эхо Москвы
url = 'http://echo.msk.ru/news/1883690-echo.html'
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('article2.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')

article = bsObj.find("div", {"class":"typical"})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()


# Газета Вечерняя Москва
url = 'http://vm.ru/news/2016/11/30/sk-provedet-proverku-po-informatsii-o-visazhennom-iz-tramvaya-na-moroz-rebenke-342010.html'
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('article3.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text())

article = bsObj.find('div', {'class':'s-article-content-block mrgbtm20'})

for item in article.findAll("p"):
    t = item.get_text()
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    if clean_t.find('ЧИТАЙТЕ ТАКЖЕ') >=0:
        break
    f.write(clean_t + '\n')

f.close()


# Комсомольская правда
url = 'http://www.kp.ru/online/news/2586020/'
req = urllib.request.Request(url)
with urllib.request.urlopen(req) as response:
    html = response.read().decode('utf-8')
bsObj = BeautifulSoup(html, "html.parser")

f = open('article4.txt', 'w', encoding='utf-8')
h1 = bsObj.h1
f.write(h1.get_text()+'\n')


article = bsObj.find("div", {"itemprop":"articleBody"})


for item in article.findAll("p"):
    t = item.get_text()
    if t == '':
        continue
    clean_t = regSpace.sub(" ", t)
    clean_t = clean_t.replace('\n', ' ')
    f.write(clean_t + '\n')

f.close()

