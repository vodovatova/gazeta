
sets = []

for i in range(1, 5):
    f = open('article' + str(i) +'.txt', 'r', encoding='utf-8')
    text = f.read()
    f.close()
    text = text.lower()
    text = text.replace('.', '')
    text = text.replace(',', '')
    text = text.replace('ё', 'е')
    text = text.replace('«', '')
    text = text.replace('»', '')
    text = text.replace('(', '')
    text = text.replace(')', '')
    text = text.replace('"', '')
    text = text.replace('/', '')
    text = text.replace('-', ' ')
    text = text.replace('—', ' ')
    text = text.replace('№', ' ')
    sets.append(set(text.split()))


inter = sets[0] & sets[1] & sets[2] & sets[3]
interlst = list(inter)
f = open('intersection.txt', 'w', encoding='utf-8')
for word in sorted(interlst):
    f.write(word+'\n')
f.close()

symdif = sets[0] ^ sets[1] ^ sets[2] ^ sets[3]
symdiflst = list(symdif)
f = open('symdiff.txt', 'w', encoding='utf-8')
for word in sorted(symdiflst):
    f.write(word+'\n')
f.close()